import SwiftUI

struct VeltrixBalanceCard: View {
    @EnvironmentObject private var model: VeltrixModel
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var range = ChartRange.week
    let portfolio: Portfolio
    let value: Decimal?
    let openChart: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 4) {
                Text("Portfolio value").font(.subheadline.weight(.medium))
                Button {
                    withAnimation(reduceMotion || UITestMode.enabled ? nil : .easeOut(duration: 0.2)) {
                        model.hide.toggle()
                    }
                    Feedback.tap()
                } label: {
                    Image(systemName: model.hide ? "eye.slash" : "eye")
                        .font(.footnote).frame(width: 44, height: 44)
                }
                .accessibilityLabel(Text(model.hide ? "Show balances" : "Hide balances"))
                Spacer(minLength: 2)
                Menu {
                    Picker("Display currency", selection: $model.currency) {
                        ForEach(Fiat.currencies, id: \.self) { code in
                            Text(verbatim: code).tag(code)
                        }
                    }
                } label: {
                    HStack(spacing: 5) {
                        Text(verbatim: model.currency)
                        Image(systemName: "chevron.down").font(.system(size: 8, weight: .bold))
                    }
                    .font(.caption.monospacedDigit().weight(.semibold))
                    .padding(.horizontal, 10).frame(minHeight: 44)
                }
                .accessibilityLabel(Text("Display currency"))
            }
            .foregroundStyle(Color.vxHighlight)
            CountValue(text: model.money(value))
                .font(.system(size: 43, weight: .semibold))
                .tracking(-1.5).lineLimit(1).minimumScaleFactor(0.25)
                .accessibilityIdentifier("portfolio.total")
            HStack(spacing: 7) {
                let daily = try? portfolio.daily(now: .now, prices: model.prices)
                Text("24h P&L").foregroundStyle(Color.vxMuted)
                Text(verbatim: model.signedMoney(daily?.value))
                if !model.hide { ChangeText(change: daily?.percent) }
            }.font(.caption.monospacedDigit()).lineLimit(1).minimumScaleFactor(0.65)
            if !model.hide {
                VeltrixChart(samples: portfolio.chart(range: range, performance: true), range: $range,
                             candles: .constant(false), allowsCandles: false, height: 78, mini: true) {
                    model.signedMoney($0)
                }.font(.caption2.monospacedDigit())
                chartControls
            }
            Divider().overlay(Color.vxSeparator)
            HStack(spacing: 6) {
                Text("Available cash").foregroundStyle(Color.vxMuted)
                Spacer(minLength: 4)
                CountValue(text: model.money(try? portfolio.freeCash()))
                    .lineLimit(1).minimumScaleFactor(0.4)
            }.font(.subheadline.monospacedDigit())
            Label("Simulation", systemImage: "circle.dotted")
                .font(.caption2.weight(.medium)).foregroundStyle(Color.vxMuted)
        }
        .buttonStyle(.plain)
        .padding(.horizontal, 17)
        .padding(.top, 6)
        .padding(.bottom, 15)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background { metalSurface }
    }

    private var chartControls: some View {
        HStack(spacing: 4) {
            ForEach([ChartRange.day, .week, .month, .all], id: \.self) { period in
                Button {
                    range = period
                    Feedback.tap()
                } label: {
                    Text(verbatim: period.displayTitle)
                        .font(.caption2.monospaced().weight(.semibold))
                        .foregroundStyle(range == period ? Color.vxText : Color.vxMuted)
                        .frame(maxWidth: .infinity, minHeight: 34)
                        .background(range == period ? Color.vxText.opacity(0.11) : .clear, in: Capsule())
                }
                .accessibilityAddTraits(range == period ? .isSelected : [])
            }
            Button(action: openChart) {
                Image(systemName: "arrow.up.left.and.arrow.down.right")
                    .font(.caption.weight(.medium))
                    .frame(width: 44, height: 34)
            }
            .accessibilityLabel(Text("Full screen chart"))
        }
    }

    private var metalSurface: some View {
        let shape = RoundedRectangle(cornerRadius: 24)
        return shape
            .fill(LinearGradient(colors: [.vxSurface, .vxCard, VeltrixTheme.secondaryBackground],
                                 startPoint: .topLeading, endPoint: .bottomTrailing))
            .overlay {
                Canvas { context, size in
                    var grain = Path()
                    for row in stride(from: 0, to: Int(size.height), by: 3) {
                        let y = CGFloat(row)
                        grain.move(to: CGPoint(x: CGFloat((row * 13) % 67), y: y))
                        grain.addLine(to: CGPoint(x: size.width, y: y + 2))
                    }
                    context.stroke(grain, with: .color(.vxHighlight.opacity(0.045)), lineWidth: 0.5)
                }.clipShape(shape)
            }
            .overlay(shape.strokeBorder(LinearGradient(colors: [.vxHighlight.opacity(0.42), .vxSeparator],
                                                       startPoint: .topLeading, endPoint: .bottomTrailing)))
            .allowsHitTesting(false)
            .accessibilityHidden(true)
    }
}
